from django.core.paginator import Paginator
from django.db.models import F
from django.shortcuts import get_object_or_404, render
from .models import Article


def article_list(request):
    articles = Article.objects.filter(is_published=True)
    paginator = Paginator(articles, 9)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'articles/article_list.html', {'page_obj': page_obj})


def article_detail(request, slug):
    article = get_object_or_404(Article, slug=slug, is_published=True)
    Article.objects.filter(pk=article.pk).update(views_count=F('views_count') + 1)
    related = Article.objects.filter(is_published=True).exclude(pk=article.pk)[:3]
    return render(request, 'articles/article_detail.html', {'article': article, 'related': related})
