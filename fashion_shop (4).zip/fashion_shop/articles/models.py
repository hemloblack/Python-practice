from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from products.models import validate_image_size


class Article(models.Model):
    title = models.CharField(max_length=200, verbose_name='عنوان مقاله')
    slug = models.SlugField(max_length=220, unique=True, blank=True, allow_unicode=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='articles', verbose_name='نویسنده')
    cover_image = models.ImageField(upload_to='articles/%Y/%m/', validators=[validate_image_size], verbose_name='تصویر شاخص')
    summary = models.CharField(max_length=300, verbose_name='خلاصه')
    content = models.TextField(verbose_name='متن کامل مقاله')
    is_published = models.BooleanField(default=True, verbose_name='منتشر شده')
    published_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    views_count = models.PositiveIntegerField(default=0, verbose_name='تعداد بازدید')

    class Meta:
        verbose_name = 'مقاله'
        verbose_name_plural = 'مقالات'
        ordering = ['-published_at']

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('articles:article_detail', kwargs={'slug': self.slug})
