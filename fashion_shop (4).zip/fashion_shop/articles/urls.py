from django.urls import path
from . import views

app_name = 'articles'

urlpatterns = [
    path('', views.article_list, name='article_list'),
    path('<uslug:slug>/', views.article_detail, name='article_detail'),
]
