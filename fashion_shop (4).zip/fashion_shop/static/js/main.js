// انتخاب گونه محصول (ترکیب سایز/رنگ) — بر اساس variant واقعی و موجودی
document.addEventListener('click', function (e) {
  const chip = e.target.closest('.variant-chip');
  if (!chip || chip.classList.contains('variant-chip-disabled')) return;
  const group = chip.closest('.variant-options');
  group.querySelectorAll('.variant-chip').forEach(c => c.classList.remove('selected'));
  chip.classList.add('selected');
  const hiddenInput = document.getElementById('selectedVariantId');
  if (hiddenInput) hiddenInput.value = chip.dataset.variantId;
  const hint = document.getElementById('variantHint');
  if (hint) hint.style.display = 'none';
});

// جلوگیری از افزودن به سبد بدون انتخاب سایز/رنگ (وقتی محصول گونه دارد)
document.addEventListener('submit', function (e) {
  if (e.target.id !== 'addToCartForm') return;
  const hiddenInput = document.getElementById('selectedVariantId');
  if (hiddenInput && !hiddenInput.value) {
    e.preventDefault();
    const hint = document.getElementById('variantHint');
    if (hint) { hint.style.display = 'block'; hint.style.color = '#d63e83'; hint.textContent = 'لطفاً یکی از سایز/رنگ‌های موجود را انتخاب کنید.'; }
  }
});

// گالری تصویر محصول
document.addEventListener('click', function (e) {
  if (e.target.closest('.product-gallery-thumbs')) {
    const img = e.target.closest('img');
    if (!img) return;
    document.querySelector('.product-gallery-main img').src = img.src;
  }
});

// افزایش/کاهش تعداد
document.addEventListener('click', function (e) {
  if (e.target.classList.contains('qty-plus') || e.target.classList.contains('qty-minus')) {
    const box = e.target.closest('.qty-box');
    const input = box.querySelector('input');
    let val = parseInt(input.value || '1');
    val = e.target.classList.contains('qty-plus') ? val + 1 : Math.max(1, val - 1);
    input.value = val;
  }
});

// بارگذاری AJAX شهرها بر اساس استان انتخاب‌شده
document.addEventListener('DOMContentLoaded', function () {
  const provinceSelect = document.getElementById('id_province');
  const citySelect = document.getElementById('id_city');
  if (provinceSelect && citySelect) {
    provinceSelect.addEventListener('change', function () {
      const provinceId = this.value;
      citySelect.innerHTML = '<option>در حال بارگذاری...</option>';
      fetch(`/accounts/ajax/load-cities/?province_id=${provinceId}`)
        .then(res => res.json())
        .then(data => {
          citySelect.innerHTML = '<option value="">شهر را انتخاب کنید</option>';
          data.forEach(city => {
            const opt = document.createElement('option');
            opt.value = city.id;
            opt.textContent = city.name;
            citySelect.appendChild(opt);
          });
        });
    });
  }
});

// شمارش معکوس ارسال مجدد کد OTP
document.addEventListener('DOMContentLoaded', function () {
  const timerEl = document.getElementById('resend-timer');
  const resendBtn = document.getElementById('resend-btn');
  if (timerEl && resendBtn) {
    let seconds = parseInt(timerEl.dataset.seconds || '90');
    resendBtn.style.display = 'none';
    const interval = setInterval(() => {
      seconds--;
      timerEl.textContent = seconds;
      if (seconds <= 0) {
        clearInterval(interval);
        timerEl.parentElement.style.display = 'none';
        resendBtn.style.display = 'inline-flex';
      }
    }, 1000);
  }
});

// ===== منوی کشویی موبایل =====
document.addEventListener('DOMContentLoaded', function () {
  const drawer = document.getElementById('navDrawer');
  const overlay = document.getElementById('navOverlay');
  const openBtn = document.getElementById('menuOpenBtn');
  const closeBtn = document.getElementById('menuCloseBtn');

  function openDrawer() {
    drawer.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer() {
    drawer.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (openBtn) openBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeDrawer();
  });
});

// ===== تم تاریک / روشن =====
document.addEventListener('DOMContentLoaded', function () {
  const toggleBtn = document.getElementById('themeToggleBtn');
  if (!toggleBtn) return;

  toggleBtn.addEventListener('click', function () {
    const html = document.documentElement;
    const isDark = html.getAttribute('data-theme') === 'dark';
    if (isDark) {
      html.removeAttribute('data-theme');
      localStorage.setItem('theme', 'light');
    } else {
      html.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    }
  });
});
