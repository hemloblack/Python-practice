"""
پنل مدیریت اختصاصی سایت (جدا از /admin/ جنگو).
همه ویوها فقط برای کاربران staff قابل دسترسی هستند (staff_member_required).
این پنل دقیقا قابلیت‌های خواسته‌شده را پوشش می‌دهد:
- ثبت محصول جدید با فرم کامل (تصاویر + سایز/رنگ)
- نوشتن مقاله و آموزه
- دیدن سفارش‌ها، تایید سفارش، تغییر وضعیت، ثبت کد رهگیری
- ویرایش/حذف محصول و تغییر قیمت
- ثبت و آپلود بنر سایت
"""
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.decorators import method_decorator

from articles.forms import ArticleForm
from articles.models import Article
from core.models import Banner
from orders.models import Order, OrderStatusLog
from products.forms import ProductForm, ProductImageFormSet, ProductVariantFormSet
from products.models import Product


def staff_required(view_func):
    return login_required(staff_member_required(view_func, login_url='accounts:request_otp'))


@staff_required
def dashboard_home(request):
    stats = {
        'total_products': Product.objects.count(),
        'pending_orders': Order.objects.filter(status__in=['pending_payment', 'confirming']).count(),
        'processing_orders': Order.objects.filter(status='processing').count(),
        'total_articles': Article.objects.count(),
    }
    recent_orders = Order.objects.all()[:10]
    return render(request, 'dashboard/home.html', {'stats': stats, 'recent_orders': recent_orders})


# ---------------------- محصولات ----------------------

@staff_required
def product_list(request):
    products = Product.objects.all().select_related('category')
    return render(request, 'dashboard/product_list.html', {'products': products})


@staff_required
def product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        image_formset = ProductImageFormSet(request.POST, request.FILES, prefix='images')
        variant_formset = ProductVariantFormSet(request.POST, prefix='variants')

        if form.is_valid():
            # ابتدا معتبربودن formsetها را با یک instance موقت (بدون ذخیره در دیتابیس) بررسی می‌کنیم
            temp_product = form.save(commit=False)
            image_formset.instance = temp_product
            variant_formset.instance = temp_product

            if image_formset.is_valid() and variant_formset.is_valid():
                product = form.save()
                image_formset.instance = product
                variant_formset.instance = product

                images = image_formset.save(commit=False)
                for i, img in enumerate(images):
                    img.order = i
                    img.save()
                for obj in image_formset.deleted_objects:
                    obj.delete()

                variant_formset.save()

                messages.success(request, 'محصول با موفقیت ثبت شد.')
                return redirect('dashboard:product_list')
            else:
                messages.error(request, 'در ثبت تصاویر یا گونه‌های محصول خطایی رخ داد؛ پایین فرم را بررسی کنید.')
    else:
        form = ProductForm()
        image_formset = ProductImageFormSet(prefix='images')
        variant_formset = ProductVariantFormSet(prefix='variants')
    return render(request, 'dashboard/product_form.html', {
        'form': form, 'image_formset': image_formset, 'variant_formset': variant_formset, 'is_edit': False,
    })


@staff_required
def product_edit(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        image_formset = ProductImageFormSet(request.POST, request.FILES, instance=product, prefix='images')
        variant_formset = ProductVariantFormSet(request.POST, instance=product, prefix='variants')
        if form.is_valid() and image_formset.is_valid() and variant_formset.is_valid():
            form.save()
            images = image_formset.save(commit=False)
            for i, img in enumerate(images):
                img.order = img.order or i
                img.save()
            for obj in image_formset.deleted_objects:
                obj.delete()
            variant_formset.save()
            messages.success(request, 'محصول به‌روزرسانی شد.')
            return redirect('dashboard:product_list')
        else:
            messages.error(request, 'خطایی در فرم وجود دارد؛ لطفاً موارد مشخص‌شده را بررسی کنید.')
    else:
        form = ProductForm(instance=product)
        image_formset = ProductImageFormSet(instance=product, prefix='images')
        variant_formset = ProductVariantFormSet(instance=product, prefix='variants')
    return render(request, 'dashboard/product_form.html', {
        'form': form, 'image_formset': image_formset, 'variant_formset': variant_formset,
        'is_edit': True, 'product': product,
    })


@staff_required
def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        messages.success(request, 'محصول حذف شد.')
        return redirect('dashboard:product_list')
    return render(request, 'dashboard/confirm_delete.html', {'object': product, 'type': 'محصول'})


# ---------------------- مقالات ----------------------

@staff_required
def article_list(request):
    articles = Article.objects.all()
    return render(request, 'dashboard/article_list.html', {'articles': articles})


@staff_required
def article_create(request):
    if request.method == 'POST':
        form = ArticleForm(request.POST, request.FILES)
        if form.is_valid():
            article = form.save(commit=False)
            article.author = request.user
            article.save()
            messages.success(request, 'مقاله منتشر شد.')
            return redirect('dashboard:article_list')
    else:
        form = ArticleForm()
    return render(request, 'dashboard/article_form.html', {'form': form, 'is_edit': False})


@staff_required
def article_edit(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        form = ArticleForm(request.POST, request.FILES, instance=article)
        if form.is_valid():
            form.save()
            messages.success(request, 'مقاله به‌روزرسانی شد.')
            return redirect('dashboard:article_list')
    else:
        form = ArticleForm(instance=article)
    return render(request, 'dashboard/article_form.html', {'form': form, 'is_edit': True, 'article': article})


@staff_required
def article_delete(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        article.delete()
        messages.success(request, 'مقاله حذف شد.')
        return redirect('dashboard:article_list')
    return render(request, 'dashboard/confirm_delete.html', {'object': article, 'type': 'مقاله'})


# ---------------------- سفارش‌ها ----------------------

@staff_required
def order_list(request):
    status = request.GET.get('status')
    orders = Order.objects.all()
    if status:
        orders = orders.filter(status=status)
    return render(request, 'dashboard/order_list.html', {'orders': orders, 'status_choices': Order.STATUS_CHOICES, 'current_status': status})


@staff_required
def order_detail(request, order_number):
    order = get_object_or_404(Order, order_number=order_number)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        tracking_code = request.POST.get('tracking_code', '').strip()
        admin_note = request.POST.get('admin_note', '').strip()

        old_status = order.status
        if new_status and new_status != old_status:
            order.status = new_status
            if new_status == 'confirming' and not order.confirmed_at:
                order.confirmed_at = timezone.now()
            if new_status == 'shipped' and not order.shipped_at:
                order.shipped_at = timezone.now()
            if new_status == 'cancelled' and old_status != 'cancelled':
                order.restore_stock()
            OrderStatusLog.objects.create(order=order, old_status=old_status, new_status=new_status, changed_by=request.user)

        if tracking_code:
            order.tracking_code = tracking_code
        order.admin_note = admin_note
        order.save()
        messages.success(request, 'سفارش به‌روزرسانی شد.')
        return redirect('dashboard:order_detail', order_number=order.order_number)

    return render(request, 'dashboard/order_detail.html', {'order': order})


# ---------------------- بنرها ----------------------

@staff_required
def banner_list(request):
    banners = Banner.objects.all()
    return render(request, 'dashboard/banner_list.html', {'banners': banners})


@staff_required
def banner_create(request):
    if request.method == 'POST':
        Banner.objects.create(
            title=request.POST.get('title'),
            subtitle=request.POST.get('subtitle', ''),
            image=request.FILES.get('image'),
            link_url=request.POST.get('link_url', ''),
            is_active=bool(request.POST.get('is_active')),
            order=int(request.POST.get('order') or 0),
        )
        messages.success(request, 'بنر با موفقیت آپلود شد.')
        return redirect('dashboard:banner_list')
    return render(request, 'dashboard/banner_form.html')


@staff_required
def banner_delete(request, pk):
    banner = get_object_or_404(Banner, pk=pk)
    if request.method == 'POST':
        banner.delete()
        messages.success(request, 'بنر حذف شد.')
        return redirect('dashboard:banner_list')
    return render(request, 'dashboard/confirm_delete.html', {'object': banner, 'type': 'بنر'})
