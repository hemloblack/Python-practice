from django.db import models


class Banner(models.Model):
    """بنرهای اسلایدر صفحه اصلی — قابل آپلود توسط ادمین"""
    title = models.CharField(max_length=150, verbose_name='عنوان بنر')
    subtitle = models.CharField(max_length=250, blank=True, verbose_name='زیرعنوان')
    image = models.ImageField(upload_to='banners/', verbose_name='تصویر بنر')
    link_url = models.CharField(max_length=300, blank=True, verbose_name='لینک مقصد', help_text='مثلا /products/category/kids/')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    order = models.PositiveIntegerField(default=0, verbose_name='ترتیب نمایش')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'بنر'
        verbose_name_plural = 'بنرها'
        ordering = ['order', '-created_at']

    def __str__(self):
        return self.title


class SiteSetting(models.Model):
    """تنظیمات عمومی سایت (تک‌رکورد) برای هدر/فوتر"""
    site_name = models.CharField(max_length=100, default='فروشگاه پوشاک')
    logo = models.ImageField(upload_to='site/', blank=True, null=True)
    footer_about = models.TextField(blank=True, verbose_name='متن درباره ما در فوتر')
    support_phone = models.CharField(max_length=20, blank=True, verbose_name='شماره پشتیبانی')
    support_email = models.EmailField(blank=True, verbose_name='ایمیل پشتیبانی')
    address = models.CharField(max_length=300, blank=True, verbose_name='آدرس')
    instagram_url = models.URLField(blank=True)
    telegram_url = models.URLField(blank=True)

    class Meta:
        verbose_name = 'تنظیمات سایت'
        verbose_name_plural = 'تنظیمات سایت'

    def __str__(self):
        return self.site_name

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj
