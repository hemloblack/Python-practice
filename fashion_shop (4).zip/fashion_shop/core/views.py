from django.shortcuts import render
from products.models import Category, Product
from articles.models import Article
from .models import Banner


def home(request):
    banners = Banner.objects.filter(is_active=True)
    categories = Category.objects.filter(is_active=True, parent=None)
    featured_products = Product.objects.filter(is_active=True, is_featured=True)[:8]
    discounted_products = Product.objects.filter(is_active=True, discount_percent__gt=0)[:8]
    latest_products = Product.objects.filter(is_active=True)[:12]
    latest_articles = Article.objects.filter(is_published=True)[:3]
    return render(request, 'core/home.html', {
        'banners': banners,
        'categories': categories,
        'featured_products': featured_products,
        'discounted_products': discounted_products,
        'latest_products': latest_products,
        'latest_articles': latest_articles,
    })


def about(request):
    return render(request, 'core/about.html')


def contact(request):
    return render(request, 'core/contact.html')
