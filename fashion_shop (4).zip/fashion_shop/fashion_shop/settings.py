"""
Django settings for fashion_shop project.
تنظیمات پروژه فروشگاه پوشاک
"""

import os
from pathlib import Path
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

# -------------------------------------------------------------------
# امنیت پایه — مقادیر حساس از متغیرهای محیطی خوانده می‌شوند
# در سرور واقعی حتماً این‌ها را در فایل .env قرار دهید و SECRET_KEY را عوض کنید
# -------------------------------------------------------------------
SECRET_KEY = os.environ.get(
    'DJANGO_SECRET_KEY',
    'django-insecure-CHANGE-THIS-KEY-BEFORE-DEPLOY-!!!'
)

DEBUG = os.environ.get('DJANGO_DEBUG', 'True') == 'True'

ALLOWED_HOSTS = os.environ.get('DJANGO_ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',')

CSRF_TRUSTED_ORIGINS = [
    o for o in os.environ.get('DJANGO_CSRF_TRUSTED_ORIGINS', '').split(',') if o
]

# -------------------------------------------------------------------
# اپلیکیشن‌ها
# -------------------------------------------------------------------
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',

    # اپ‌های پروژه
    'accounts.apps.AccountsConfig',
    'products.apps.ProductsConfig',
    'orders.apps.OrdersConfig',
    'articles.apps.ArticlesConfig',
    'core.apps.CoreConfig',
    'payments.apps.PaymentsConfig',
    'dashboard.apps.DashboardConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # میان‌افزار محدودسازی نرخ درخواست برای OTP (ضد بروت‌فورس)
    'accounts.middleware.OTPRateLimitMiddleware',
]

ROOT_URLCONF = 'fashion_shop.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'core.context_processors.site_settings',
                'orders.context_processors.cart_summary',
            ],
        },
    },
]

WSGI_APPLICATION = 'fashion_shop.wsgi.application'

# -------------------------------------------------------------------
# دیتابیس — برای شروع sqlite، برای پروداکشن PostgreSQL توصیه می‌شود
# -------------------------------------------------------------------
DATABASES = {
    'default': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.db.backends.sqlite3'),
        'NAME': os.environ.get('DB_NAME', BASE_DIR / 'db.sqlite3'),
        'USER': os.environ.get('DB_USER', ''),
        'PASSWORD': os.environ.get('DB_PASSWORD', ''),
        'HOST': os.environ.get('DB_HOST', ''),
        'PORT': os.environ.get('DB_PORT', ''),
    }
}

# -------------------------------------------------------------------
# مدل کاربر سفارشی (احراز هویت با شماره موبایل)
# -------------------------------------------------------------------
AUTH_USER_MODEL = 'accounts.User'

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LOGIN_URL = '/accounts/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'

# -------------------------------------------------------------------
# بین‌المللی‌سازی
# -------------------------------------------------------------------
LANGUAGE_CODE = 'fa'
TIME_ZONE = 'Asia/Tehran'
USE_I18N = True
USE_TZ = True

# -------------------------------------------------------------------
# فایل‌های استاتیک و مدیا
# -------------------------------------------------------------------
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# -------------------------------------------------------------------
# تنظیمات امنیتی
# -------------------------------------------------------------------
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'
CSRF_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_AGE = 60 * 60 * 24 * 14  # ۱۴ روز
SESSION_EXPIRE_AT_BROWSER_CLOSE = False

if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# محدودیت اندازه آپلود فایل — عکس محصولات تا ۱۲ مگابایت مجاز است (اعتبارسنجی دقیق در products/models.py)
DATA_UPLOAD_MAX_MEMORY_SIZE = 20 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 20 * 1024 * 1024

# -------------------------------------------------------------------
# تنظیمات OTP
# -------------------------------------------------------------------
OTP_CODE_LENGTH = 5
OTP_EXPIRE_SECONDS = 120           # اعتبار کد: ۲ دقیقه
OTP_RESEND_WAIT_SECONDS = 90       # فاصله ارسال مجدد
OTP_MAX_ATTEMPTS = 5               # حداکثر تلاش اشتباه قبل از باطل شدن کد
OTP_MAX_REQUESTS_PER_HOUR = 5      # حداکثر درخواست کد در ساعت برای هر شماره/آی‌پی

# درگاه پیامک: فعلاً روی حالت "console" است (کد در ترمینال/لاگ چاپ می‌شود).
# وقتی سرویس‌دهنده پیامک را انتخاب کردید کافیست SMS_BACKEND را عوض کنید
# و کلیدهای API را در متغیر محیطی قرار دهید. به accounts/sms.py نگاه کنید.
SMS_BACKEND = os.environ.get('SMS_BACKEND', 'console')  # 'console' | 'kavenegar' | 'melipayamak' | 'ippanel'
SMS_API_KEY = os.environ.get('SMS_API_KEY', '')
SMS_SENDER_NUMBER = os.environ.get('SMS_SENDER_NUMBER', '')

# -------------------------------------------------------------------
# تنظیمات درگاه پرداخت زرین‌پال
# -------------------------------------------------------------------
ZARINPAL_MERCHANT_ID = os.environ.get('ZARINPAL_MERCHANT_ID', '00000000-0000-0000-0000-000000000000')
ZARINPAL_SANDBOX = os.environ.get('ZARINPAL_SANDBOX', 'True') == 'True'
ZARINPAL_CALLBACK_PATH = '/payment/verify/'

# -------------------------------------------------------------------
# لاگ‌گیری (برای پایش تلاش‌های مشکوک ورود/OTP)
# -------------------------------------------------------------------
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {'format': '[{asctime}] {levelname} {name}: {message}', 'style': '{'},
    },
    'handlers': {
        'console': {'class': 'logging.StreamHandler', 'formatter': 'verbose'},
        'security_file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': BASE_DIR / 'logs' / 'security.log',
            'maxBytes': 5 * 1024 * 1024,
            'backupCount': 5,
            'formatter': 'verbose',
        },
    },
    'loggers': {
        'django.security': {'handlers': ['console', 'security_file'], 'level': 'WARNING', 'propagate': True},
        'accounts': {'handlers': ['console', 'security_file'], 'level': 'INFO', 'propagate': True},
        'payments': {'handlers': ['console', 'security_file'], 'level': 'INFO', 'propagate': True},
    },
}
os.makedirs(BASE_DIR / 'logs', exist_ok=True)
