from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path, register_converter


class UnicodeSlugConverter:
    """اسلاگ‌های فارسی/یونیکد را نیز می‌پذیرد (برخلاف slug پیش‌فرض جنگو که فقط ASCII است)"""
    regex = r'[-\w]+'

    def to_python(self, value):
        return value

    def to_url(self, value):
        return value


register_converter(UnicodeSlugConverter, 'uslug')

urlpatterns = [
    path('admin/', admin.site.urls),  # پنل مدیریت پیش‌فرض جنگو (برای مدیر ارشد/سوپریوزر)
    path('panel/', include('dashboard.urls')),  # پنل اختصاصی مدیریت سایت (برای ادمین‌های فروشگاه)
    path('accounts/', include('accounts.urls')),
    path('articles/', include('articles.urls')),
    path('payment/', include('payments.urls')),
    path('', include('orders.urls')),
    path('', include('core.urls')),
    path('products/', include('products.urls')),
]

admin.site.site_header = 'مدیریت فروشگاه پوشاک'
admin.site.site_title = 'مدیریت فروشگاه'
admin.site.index_title = 'خوش آمدید'

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
