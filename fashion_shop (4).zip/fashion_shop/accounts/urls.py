from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('login/', views.request_otp, name='request_otp'),
    path('request-otp/', views.request_otp, name='request_otp_alt'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('complete-profile/', views.complete_profile, name='complete_profile'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.user_logout, name='logout'),
    path('addresses/', views.address_list, name='address_list'),
    path('addresses/new/', views.address_create, name='address_create'),
    path('ajax/load-cities/', views.load_cities, name='load_cities'),
]
