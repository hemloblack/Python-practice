import logging
from django.core.cache import cache

logger = logging.getLogger('accounts')

SENSITIVE_PATHS = ('/accounts/verify-otp/', '/accounts/request-otp/')


class OTPRateLimitMiddleware:
    """
    محدودسازی سادهٔ نرخ درخواست بر اساس IP برای مسیرهای حساس OTP
    (لایه اضافه در کنار محدودیت مبتنی‌بر شماره موبایل که در views.py انجام می‌شود).
    """
    MAX_REQUESTS = 20
    WINDOW_SECONDS = 60

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == 'POST' and any(request.path.startswith(p) for p in SENSITIVE_PATHS):
            ip = request.META.get('HTTP_X_FORWARDED_FOR', '').split(',')[0].strip() or request.META.get('REMOTE_ADDR')
            cache_key = f'otp_ip_rl:{ip}'
            count = cache.get(cache_key, 0)
            if count >= self.MAX_REQUESTS:
                logger.warning('IP rate-limited on %s: %s', request.path, ip)
                from django.http import HttpResponseTooManyRequests
                return HttpResponseTooManyRequests('تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد تلاش کنید.')
            cache.set(cache_key, count + 1, self.WINDOW_SECONDS)
        return self.get_response(request)
