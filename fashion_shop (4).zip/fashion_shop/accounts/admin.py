from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import Address, City, OTPRequest, Province, User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('phone_number', 'first_name', 'last_name', 'is_phone_verified', 'is_staff', 'is_active', 'created_at')
    list_filter = ('is_staff', 'is_active', 'is_phone_verified')
    search_fields = ('phone_number', 'first_name', 'last_name', 'email')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at', 'last_login')
    fieldsets = (
        (None, {'fields': ('phone_number', 'password')}),
        ('اطلاعات شخصی', {'fields': ('first_name', 'last_name', 'email', 'national_code', 'birth_date')}),
        ('دسترسی‌ها', {'fields': ('is_active', 'is_staff', 'is_superuser', 'is_phone_verified', 'groups', 'user_permissions')}),
        ('تاریخ‌ها', {'fields': ('last_login', 'created_at', 'updated_at')}),
    )
    add_fieldsets = (
        (None, {'classes': ('wide',), 'fields': ('phone_number', 'password1', 'password2')}),
    )


class CityInline(admin.TabularInline):
    model = City
    extra = 1


@admin.register(Province)
class ProvinceAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
    inlines = [CityInline]


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ('name', 'province')
    list_filter = ('province',)
    search_fields = ('name',)


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('user', 'receiver_first_name', 'receiver_last_name', 'city', 'postal_code', 'is_default')
    search_fields = ('receiver_first_name', 'receiver_last_name', 'postal_code', 'user__phone_number')
    list_filter = ('province',)


@admin.register(OTPRequest)
class OTPRequestAdmin(admin.ModelAdmin):
    """فقط برای پایش امنیتی — کدها را نباید ویرایش‌پذیر گذاشت."""
    list_display = ('phone_number', 'purpose', 'ip_address', 'is_used', 'attempts', 'created_at', 'expires_at')
    list_filter = ('purpose', 'is_used')
    search_fields = ('phone_number', 'ip_address')
    readonly_fields = [f.name for f in OTPRequest._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
