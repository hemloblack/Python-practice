from django import forms
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError

from .models import Address, City, Province, phone_validator


class PhoneNumberForm(forms.Form):
    """مرحله ۱ ورود/ثبت‌نام: گرفتن شماره موبایل"""
    phone_number = forms.CharField(
        label='شماره موبایل',
        validators=[phone_validator],
        widget=forms.TextInput(attrs={
            'placeholder': '09xxxxxxxxx', 'inputmode': 'numeric',
            'autocomplete': 'tel', 'class': 'form-input', 'dir': 'ltr'
        })
    )

    def clean_phone_number(self):
        phone = self.cleaned_data['phone_number'].strip()
        if not phone.isdigit():
            raise ValidationError('شماره موبایل باید فقط شامل رقم باشد.')
        return phone


class OTPVerifyForm(forms.Form):
    """مرحله ۲: تایید کد پیامک‌شده"""
    code = forms.CharField(
        label='کد تایید',
        max_length=8, min_length=4,
        widget=forms.TextInput(attrs={
            'placeholder': '- - - - -', 'inputmode': 'numeric',
            'autocomplete': 'one-time-code', 'class': 'form-input otp-input', 'dir': 'ltr'
        })
    )


class SetPasswordForm(forms.Form):
    """تعیین رمز عبور برای کاربر جدید (اختیاری، بعد از تایید OTP)"""
    password1 = forms.CharField(label='رمز عبور', widget=forms.PasswordInput(attrs={'class': 'form-input'}))
    password2 = forms.CharField(label='تکرار رمز عبور', widget=forms.PasswordInput(attrs={'class': 'form-input'}))

    def clean(self):
        cleaned = super().clean()
        p1, p2 = cleaned.get('password1'), cleaned.get('password2')
        if p1 and p2 and p1 != p2:
            raise ValidationError('رمزهای عبور یکسان نیستند.')
        if p1:
            password_validation.validate_password(p1)
        return cleaned


class ProfileForm(forms.Form):
    """ثبت مشخصات تکمیلی کاربر پس از ثبت‌نام"""
    first_name = forms.CharField(label='نام', max_length=100, widget=forms.TextInput(attrs={'class': 'form-input'}))
    last_name = forms.CharField(label='نام خانوادگی', max_length=100, widget=forms.TextInput(attrs={'class': 'form-input'}))
    email = forms.EmailField(label='ایمیل', required=False, widget=forms.EmailInput(attrs={'class': 'form-input', 'dir': 'ltr'}))


class AddressForm(forms.ModelForm):
    """فرم ثبت آدرس کامل (استان → شهر → کد پستی → آدرس دقیق → مشخصات گیرنده)"""

    class Meta:
        model = Address
        fields = [
            'receiver_first_name', 'receiver_last_name', 'receiver_phone',
            'province', 'city', 'postal_code', 'full_address', 'is_default',
        ]
        widgets = {
            'receiver_first_name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'نام گیرنده'}),
            'receiver_last_name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'نام خانوادگی گیرنده'}),
            'receiver_phone': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '09xxxxxxxxx', 'dir': 'ltr'}),
            'province': forms.Select(attrs={'class': 'form-input', 'id': 'id_province'}),
            'city': forms.Select(attrs={'class': 'form-input', 'id': 'id_city'}),
            'postal_code': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'کد پستی ۱۰ رقمی', 'dir': 'ltr'}),
            'full_address': forms.Textarea(attrs={'class': 'form-input', 'rows': 4, 'placeholder': 'نشانی دقیق و کامل منزل'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['province'].queryset = Province.objects.all()
        # شهرها بر اساس استانِ انتخاب‌شده با AJAX در فرانت پر می‌شود
        if 'province' in self.data:
            try:
                province_id = int(self.data.get('province'))
                self.fields['city'].queryset = City.objects.filter(province_id=province_id)
            except (ValueError, TypeError):
                self.fields['city'].queryset = City.objects.none()
        elif self.instance.pk:
            self.fields['city'].queryset = City.objects.filter(province=self.instance.province)
        else:
            self.fields['city'].queryset = City.objects.none()
