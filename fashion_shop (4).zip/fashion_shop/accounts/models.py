import random
from django.conf import settings
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone


phone_validator = RegexValidator(
    regex=r'^09\d{9}$',
    message='شماره موبایل باید به‌صورت ۰۹xxxxxxxxx وارد شود.'
)

postal_code_validator = RegexValidator(
    regex=r'^\d{10}$',
    message='کد پستی باید ۱۰ رقم باشد.'
)


class UserManager(BaseUserManager):
    """مدیریت کاربران با شماره موبایل به‌جای نام کاربری"""

    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError('شماره موبایل الزامی است')
        user = self.model(phone_number=phone_number, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, phone_number, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_phone_verified', True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError('سوپریوزر باید is_staff=True باشد')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('سوپریوزر باید is_superuser=True باشد')
        return self.create_user(phone_number, password, **extra_fields)


class User(AbstractUser):
    """
    کاربر سایت با شماره موبایل به‌عنوان شناسه اصلی ورود.
    فیلد username همچنان برای سازگاری با پنل ادمین جنگو نگه داشته شده
    ولی برای لاگین کاربران عادی استفاده نمی‌شود.
    """
    username = models.CharField(max_length=150, unique=False, blank=True, null=True)
    phone_number = models.CharField(
        max_length=11, unique=True, validators=[phone_validator],
        verbose_name='شماره موبایل'
    )
    first_name = models.CharField(max_length=100, blank=True, verbose_name='نام')
    last_name = models.CharField(max_length=100, blank=True, verbose_name='نام خانوادگی')
    email = models.EmailField(blank=True, null=True, verbose_name='ایمیل')
    is_phone_verified = models.BooleanField(default=False, verbose_name='موبایل تایید شده')
    national_code = models.CharField(max_length=10, blank=True, null=True, verbose_name='کد ملی')
    birth_date = models.DateField(blank=True, null=True, verbose_name='تاریخ تولد')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = []

    objects = UserManager()

    class Meta:
        verbose_name = 'کاربر'
        verbose_name_plural = 'کاربران'
        ordering = ['-created_at']

    def __str__(self):
        full_name = f'{self.first_name} {self.last_name}'.strip()
        return full_name if full_name else self.phone_number

    def get_full_name(self):
        full_name = f'{self.first_name} {self.last_name}'.strip()
        return full_name or self.phone_number


class Province(models.Model):
    """استان"""
    name = models.CharField(max_length=100, unique=True, verbose_name='نام استان')

    class Meta:
        verbose_name = 'استان'
        verbose_name_plural = 'استان‌ها'
        ordering = ['name']

    def __str__(self):
        return self.name


class City(models.Model):
    """شهر (وابسته به استان)"""
    province = models.ForeignKey(Province, on_delete=models.CASCADE, related_name='cities', verbose_name='استان')
    name = models.CharField(max_length=100, verbose_name='نام شهر')

    class Meta:
        verbose_name = 'شهر'
        verbose_name_plural = 'شهرها'
        unique_together = ('province', 'name')
        ordering = ['name']

    def __str__(self):
        return f'{self.name} ({self.province.name})'


class Address(models.Model):
    """آدرس‌های ثبت‌شده توسط کاربر برای ارسال سفارش"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='addresses', verbose_name='کاربر')
    receiver_first_name = models.CharField(max_length=100, verbose_name='نام گیرنده')
    receiver_last_name = models.CharField(max_length=100, verbose_name='نام خانوادگی گیرنده')
    receiver_phone = models.CharField(max_length=11, validators=[phone_validator], verbose_name='شماره تماس گیرنده')
    province = models.ForeignKey(Province, on_delete=models.PROTECT, verbose_name='استان')
    city = models.ForeignKey(City, on_delete=models.PROTECT, verbose_name='شهر')
    postal_code = models.CharField(max_length=10, validators=[postal_code_validator], verbose_name='کد پستی')
    full_address = models.TextField(verbose_name='نشانی دقیق منزل')
    is_default = models.BooleanField(default=False, verbose_name='آدرس پیش‌فرض')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'آدرس'
        verbose_name_plural = 'آدرس‌ها'
        ordering = ['-is_default', '-created_at']

    def __str__(self):
        return f'{self.receiver_first_name} {self.receiver_last_name} - {self.city}'

    def save(self, *args, **kwargs):
        if self.is_default:
            Address.objects.filter(user=self.user, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)


def generate_otp_code(length=None):
    length = length or getattr(settings, 'OTP_CODE_LENGTH', 5)
    return ''.join(str(random.randint(0, 9)) for _ in range(length))


class OTPRequest(models.Model):
    """
    درخواست کد یک‌بارمصرف. هر رکورد یک تلاش ارسال کد است؛
    تاریخچه برای پایش امنیتی (ضد بروت‌فورس) نگه داشته می‌شود.
    """
    PURPOSE_CHOICES = (
        ('register', 'ثبت‌نام / ورود'),
        ('reset_password', 'بازیابی رمز عبور'),
    )

    phone_number = models.CharField(max_length=11, validators=[phone_validator], verbose_name='شماره موبایل')
    code = models.CharField(max_length=8, verbose_name='کد')
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES, default='register')
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    is_used = models.BooleanField(default=False)
    attempts = models.PositiveSmallIntegerField(default=0, verbose_name='تعداد تلاش‌های اشتباه')
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        verbose_name = 'درخواست OTP'
        verbose_name_plural = 'درخواست‌های OTP'
        ordering = ['-created_at']
        indexes = [models.Index(fields=['phone_number', 'created_at'])]

    def __str__(self):
        return f'{self.phone_number} - {self.created_at:%Y-%m-%d %H:%M}'

    @property
    def is_expired(self):
        return timezone.now() > self.expires_at

    @property
    def max_attempts_reached(self):
        return self.attempts >= getattr(settings, 'OTP_MAX_ATTEMPTS', 5)

    def is_valid(self, code):
        """بررسی صحت کد بدون افشای اطلاعات اضافی؛ تلاش‌های اشتباه شمارش می‌شود."""
        if self.is_used or self.is_expired or self.max_attempts_reached:
            return False
        if self.code != code:
            self.attempts = models.F('attempts') + 1
            self.save(update_fields=['attempts'])
            return False
        return True

    def mark_used(self):
        self.is_used = True
        self.save(update_fields=['is_used'])
