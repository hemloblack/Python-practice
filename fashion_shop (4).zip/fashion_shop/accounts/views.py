import logging
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model, login, logout
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .forms import AddressForm, OTPVerifyForm, PhoneNumberForm, ProfileForm, SetPasswordForm
from .models import Address, City, OTPRequest, generate_otp_code
from .sms import SMSSendError, send_otp_sms

logger = logging.getLogger('accounts')
User = get_user_model()


def _client_ip(request):
    xff = request.META.get('HTTP_X_FORWARDED_FOR')
    return xff.split(',')[0].strip() if xff else request.META.get('REMOTE_ADDR')


def _hourly_request_count(phone_number, ip):
    since = timezone.now() - timezone.timedelta(hours=1)
    return OTPRequest.objects.filter(phone_number=phone_number, created_at__gte=since).count()


@require_http_methods(['GET', 'POST'])
def request_otp(request):
    """مرحله ۱: کاربر شماره موبایل را وارد می‌کند و کد یک‌بارمصرف دریافت می‌کند."""
    if request.user.is_authenticated:
        return redirect('core:home')

    if request.method == 'POST':
        form = PhoneNumberForm(request.POST)
        if form.is_valid():
            phone = form.cleaned_data['phone_number']
            ip = _client_ip(request)

            # جلوگیری از سوءاستفاده: محدودیت تعداد درخواست کد در ساعت
            if _hourly_request_count(phone, ip) >= settings.OTP_MAX_REQUESTS_PER_HOUR:
                logger.warning('OTP rate-limit exceeded for %s from %s', phone, ip)
                messages.error(request, 'تعداد درخواست‌های شما زیاد بوده. لطفاً کمی بعد دوباره تلاش کنید.')
                return render(request, 'accounts/request_otp.html', {'form': form})

            # جلوگیری از ارسال مکرر در بازه کوتاه
            recent = OTPRequest.objects.filter(phone_number=phone).order_by('-created_at').first()
            if recent and (timezone.now() - recent.created_at).total_seconds() < settings.OTP_RESEND_WAIT_SECONDS and not recent.is_expired:
                wait = int(settings.OTP_RESEND_WAIT_SECONDS - (timezone.now() - recent.created_at).total_seconds())
                messages.error(request, f'لطفاً {wait} ثانیه دیگر دوباره تلاش کنید.')
                return render(request, 'accounts/request_otp.html', {'form': form})

            code = generate_otp_code()
            otp = OTPRequest.objects.create(
                phone_number=phone, code=code, ip_address=ip,
                expires_at=timezone.now() + timezone.timedelta(seconds=settings.OTP_EXPIRE_SECONDS),
            )
            try:
                send_otp_sms(phone, code)
            except SMSSendError as e:
                logger.error('SMS send failed: %s', e)
                messages.error(request, 'ارسال پیامک با خطا مواجه شد. لطفاً بعداً تلاش کنید.')
                return render(request, 'accounts/request_otp.html', {'form': form})

            request.session['otp_phone'] = phone
            request.session['otp_id'] = otp.id
            return redirect('accounts:verify_otp')
    else:
        form = PhoneNumberForm()

    return render(request, 'accounts/request_otp.html', {'form': form})


@require_http_methods(['GET', 'POST'])
def verify_otp(request):
    """مرحله ۲: بررسی کد ارسال‌شده."""
    phone = request.session.get('otp_phone')
    otp_id = request.session.get('otp_id')
    if not phone or not otp_id:
        return redirect('accounts:request_otp')

    try:
        otp = OTPRequest.objects.get(id=otp_id, phone_number=phone)
    except OTPRequest.DoesNotExist:
        return redirect('accounts:request_otp')

    if request.method == 'POST':
        form = OTPVerifyForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['code']
            if otp.max_attempts_reached:
                messages.error(request, 'تعداد تلاش‌های مجاز تمام شده. کد جدید درخواست کنید.')
                return redirect('accounts:request_otp')
            if otp.is_expired:
                messages.error(request, 'کد منقضی شده است. دوباره درخواست دهید.')
                return redirect('accounts:request_otp')
            if otp.is_valid(code):
                otp.mark_used()
                user, created = User.objects.get_or_create(phone_number=phone)
                if created:
                    logger.info('New user registered via OTP: %s', phone)
                user.is_phone_verified = True
                user.save(update_fields=['is_phone_verified'])
                login(request, user)
                request.session.pop('otp_phone', None)
                request.session.pop('otp_id', None)

                if created or not user.first_name:
                    return redirect('accounts:complete_profile')
                return redirect(request.GET.get('next') or 'core:home')
            else:
                messages.error(request, 'کد وارد شده صحیح نیست.')
    else:
        form = OTPVerifyForm()

    return render(request, 'accounts/verify_otp.html', {
        'form': form, 'phone': phone, 'resend_wait': settings.OTP_RESEND_WAIT_SECONDS,
    })


@login_required
def complete_profile(request):
    """تکمیل مشخصات پس از اولین ورود"""
    if request.method == 'POST':
        form = ProfileForm(request.POST)
        if form.is_valid():
            request.user.first_name = form.cleaned_data['first_name']
            request.user.last_name = form.cleaned_data['last_name']
            request.user.email = form.cleaned_data.get('email') or None
            request.user.save()
            messages.success(request, 'مشخصات با موفقیت ثبت شد.')
            return redirect('accounts:dashboard')
    else:
        form = ProfileForm(initial={'first_name': request.user.first_name, 'last_name': request.user.last_name, 'email': request.user.email})
    return render(request, 'accounts/complete_profile.html', {'form': form})


@login_required
def dashboard(request):
    addresses = request.user.addresses.all()
    orders = request.user.orders.all()[:10] if hasattr(request.user, 'orders') else []
    return render(request, 'accounts/dashboard.html', {'addresses': addresses, 'orders': orders})


@login_required
def address_list(request):
    addresses = request.user.addresses.all()
    return render(request, 'accounts/address_list.html', {'addresses': addresses})


@login_required
def address_create(request):
    if request.method == 'POST':
        form = AddressForm(request.POST)
        if form.is_valid():
            address = form.save(commit=False)
            address.user = request.user
            address.save()
            messages.success(request, 'آدرس با موفقیت ثبت شد.')
            next_url = request.GET.get('next')
            return redirect(next_url or 'accounts:address_list')
    else:
        form = AddressForm()
    return render(request, 'accounts/address_form.html', {'form': form})


@login_required
def load_cities(request):
    """AJAX: بارگذاری لیست شهرهای یک استان"""
    province_id = request.GET.get('province_id')
    cities = City.objects.filter(province_id=province_id).order_by('name').values('id', 'name')
    return JsonResponse(list(cities), safe=False)


def user_logout(request):
    logout(request)
    return redirect('core:home')
