"""
لایه انتزاعی ارسال پیامک OTP.

به‌جای وابسته‌کردن مستقیم کد به یک سرویس‌دهنده خاص، این فایل یک تابع واحد
send_otp_sms(phone_number, code) دارد که بر اساس settings.SMS_BACKEND
به بک‌اند مناسب متصل می‌شود.

وقتی سرویس پیامک را انتخاب کردید کافی است:
1) settings.SMS_BACKEND را روی 'kavenegar' / 'melipayamak' / 'ippanel' بگذارید
2) SMS_API_KEY (و در صورت نیاز SMS_SENDER_NUMBER) را در متغیر محیطی ست کنید
3) تابع مربوطه در پایین را کامل کنید (نمونه‌ی کاوه‌نگار پیاده شده، بقیه placeholder هستند)

در حالت فعلی (SMS_BACKEND='console') کد به‌جای پیامک واقعی در لاگ/ترمینال چاپ می‌شود
تا بتوانید کل روند ثبت‌نام/ورود را بدون هزینه پیامک تست کنید.
"""
import logging
from django.conf import settings

logger = logging.getLogger('accounts')


class SMSSendError(Exception):
    """در صورت خطا در ارسال پیامک raise می‌شود."""
    pass


def send_otp_sms(phone_number: str, code: str) -> bool:
    backend = getattr(settings, 'SMS_BACKEND', 'console')
    text = f'کد تایید شما: {code}\nفروشگاه پوشاک - این کد را در اختیار دیگران قرار ندهید.'

    if backend == 'console':
        logger.info('SMS[console] to %s: %s', phone_number, text)
        print(f'\n===== SMS (حالت شبیه‌سازی) =====\nبه: {phone_number}\nمتن: {text}\n================================\n')
        return True

    if backend == 'kavenegar':
        return _send_via_kavenegar(phone_number, code)

    if backend == 'melipayamak':
        return _send_via_melipayamak(phone_number, code)

    if backend == 'ippanel':
        return _send_via_ippanel(phone_number, code)

    raise SMSSendError(f'SMS_BACKEND نامعتبر است: {backend}')


def _send_via_kavenegar(phone_number, code):
    """
    نمونه پیاده‌سازی برای کاوه‌نگار (کتابخانه: pip install kavenegar)
    مستندات: https://kavenegar.com/rest.html
    """
    try:
        from kavenegar import KavenegarAPI, APIException, HTTPException
    except ImportError:
        raise SMSSendError('برای استفاده از کاوه‌نگار: pip install kavenegar')

    try:
        api = KavenegarAPI(settings.SMS_API_KEY)
        params = {
            'receptor': phone_number,
            'template': 'verify',   # نام قالب OTP در پنل کاوه‌نگار
            'token': code,
            'type': 'sms',
        }
        api.verify_lookup(params)
        return True
    except (APIException, HTTPException) as e:
        logger.error('خطای ارسال پیامک کاوه‌نگار: %s', e)
        raise SMSSendError(str(e))


def _send_via_melipayamak(phone_number, code):
    """placeholder — پیاده‌سازی بر اساس مستندات ملی‌پیامک انجام شود:
    https://www.melipayamak.com/api/"""
    raise NotImplementedError('بک‌اند ملی‌پیامک هنوز پیاده‌سازی نشده است.')


def _send_via_ippanel(phone_number, code):
    """placeholder — پیاده‌سازی بر اساس مستندات آی‌پی‌پنل انجام شود:
    https://ippanel.com/webservice"""
    raise NotImplementedError('بک‌اند آی‌پی‌پنل هنوز پیاده‌سازی نشده است.')
