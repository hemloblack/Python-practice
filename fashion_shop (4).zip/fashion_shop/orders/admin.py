from django.contrib import admin
from django.utils import timezone
from .models import Cart, CartItem, Order, OrderItem, OrderStatusLog


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('product', 'product_title', 'variant_label', 'unit_price', 'quantity')
    can_delete = False


class OrderStatusLogInline(admin.TabularInline):
    model = OrderStatusLog
    extra = 0
    readonly_fields = ('old_status', 'new_status', 'changed_by', 'created_at')
    can_delete = False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    """
    پنل مدیریت سفارش‌ها — دیدن سفارش‌ها، تایید سفارش، تغییر وضعیت،
    و ثبت کد رهگیری پستی هنگام ارسال، دقیقا طبق روند خواسته‌شده.
    """
    list_display = ('order_number', 'user', 'status', 'grand_total_display', 'tracking_code', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('order_number', 'user__phone_number', 'tracking_code')
    readonly_fields = ('order_number', 'user', 'address', 'items_total', 'grand_total', 'created_at', 'updated_at')
    inlines = [OrderItemInline, OrderStatusLogInline]
    actions = ['mark_confirming', 'mark_processing', 'mark_shipped', 'mark_delivered', 'mark_cancelled']
    fieldsets = (
        ('اطلاعات سفارش', {'fields': ('order_number', 'user', 'address', 'status', 'tracking_code')}),
        ('مبالغ', {'fields': ('items_total', 'shipping_cost', 'discount_total', 'grand_total')}),
        ('یادداشت', {'fields': ('admin_note',)}),
        ('تاریخ‌ها', {'fields': ('created_at', 'updated_at', 'confirmed_at', 'shipped_at')}),
    )

    def grand_total_display(self, obj):
        return f'{obj.grand_total:,} تومان'
    grand_total_display.short_description = 'مبلغ نهایی'

    def save_model(self, request, obj, form, change):
        if change:
            old_status = Order.objects.get(pk=obj.pk).status
            if old_status != obj.status:
                OrderStatusLog.objects.create(order=obj, old_status=old_status, new_status=obj.status, changed_by=request.user)
                if obj.status == 'confirming' and not obj.confirmed_at:
                    obj.confirmed_at = timezone.now()
                if obj.status == 'shipped' and not obj.shipped_at:
                    obj.shipped_at = timezone.now()
                if obj.status == 'cancelled' and old_status != 'cancelled':
                    obj.restore_stock()
        super().save_model(request, obj, form, change)

    def _bulk_set_status(self, request, queryset, status):
        for order in queryset:
            old_status = order.status
            order.status = status
            order.save(update_fields=['status'])
            if status == 'cancelled' and old_status != 'cancelled':
                order.restore_stock()
            OrderStatusLog.objects.create(order=order, old_status=old_status, new_status=status, changed_by=request.user)

    def mark_confirming(self, request, queryset):
        self._bulk_set_status(request, queryset, 'confirming')
    mark_confirming.short_description = 'تایید سفارش‌های انتخاب‌شده'

    def mark_processing(self, request, queryset):
        self._bulk_set_status(request, queryset, 'processing')
    mark_processing.short_description = 'انتقال به «در حال پردازش»'

    def mark_shipped(self, request, queryset):
        self._bulk_set_status(request, queryset, 'shipped')
    mark_shipped.short_description = 'علامت‌گذاری به‌عنوان «ارسال شده»'

    def mark_delivered(self, request, queryset):
        self._bulk_set_status(request, queryset, 'delivered')
    mark_delivered.short_description = 'علامت‌گذاری به‌عنوان «تحویل داده شده»'

    def mark_cancelled(self, request, queryset):
        self._bulk_set_status(request, queryset, 'cancelled')
    mark_cancelled.short_description = 'لغو سفارش'


admin.site.register(Cart)
admin.site.register(CartItem)
