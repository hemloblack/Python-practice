import random
import string
from django.conf import settings
from django.db import models
from django.utils import timezone
from products.models import Product, ProductVariant
from accounts.models import Address


def generate_order_number():
    """
    شماره سفارش کاملاً عددی و یکتا برای پیگیری سفارش.
    ترکیبی از timestamp (برای ترتیب و یکتایی طبیعی) + چند رقم تصادفی
    تا حتی در صورت ثبت هم‌زمان دو سفارش هم تداخلی پیش نیاید.
    """
    while True:
        number = timezone.now().strftime('%y%m%d%H%M%S') + str(random.randint(100, 999))
        if not Order.objects.filter(order_number=number).exists():
            return number


class Cart(models.Model):
    """سبد خرید. برای کاربر مهمان بر اساس session_key و برای کاربر واردشده بر اساس user."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, related_name='cart')
    session_key = models.CharField(max_length=40, null=True, blank=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'سبد خرید'
        verbose_name_plural = 'سبدهای خرید'

    def __str__(self):
        return f'سبد خرید #{self.pk}'

    @property
    def total_items(self):
        return sum(item.quantity for item in self.items.all())

    @property
    def total_price(self):
        return sum(item.total_price for item in self.items.all())


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    variant = models.ForeignKey(ProductVariant, on_delete=models.SET_NULL, null=True, blank=True)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'آیتم سبد خرید'
        verbose_name_plural = 'آیتم‌های سبد خرید'
        unique_together = ('cart', 'product', 'variant')

    def __str__(self):
        return f'{self.product.title} × {self.quantity}'

    @property
    def unit_price(self):
        price = self.product.final_price
        if self.variant:
            price += self.variant.extra_price
        return price

    @property
    def total_price(self):
        return self.unit_price * self.quantity


class Order(models.Model):
    STATUS_CHOICES = (
        ('pending_payment', 'در انتظار پرداخت'),
        ('confirming', 'در حال تایید سفارش'),
        ('processing', 'در حال پردازش'),
        ('shipped', 'ارسال شده'),
        ('delivered', 'تحویل داده شده'),
        ('cancelled', 'لغو شده'),
    )

    order_number = models.CharField(max_length=20, unique=True, default=generate_order_number, editable=False, verbose_name='شماره سفارش / کد پیگیری')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='orders', verbose_name='کاربر')
    address = models.ForeignKey(Address, on_delete=models.PROTECT, related_name='orders', verbose_name='آدرس ارسال')

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending_payment', verbose_name='وضعیت سفارش')
    tracking_code = models.CharField(max_length=60, blank=True, verbose_name='کد رهگیری پستی', help_text='توسط ادمین پس از ارسال پر می‌شود')

    items_total = models.PositiveIntegerField(default=0, verbose_name='جمع قیمت اقلام')
    shipping_cost = models.PositiveIntegerField(default=0, verbose_name='هزینه ارسال')
    discount_total = models.PositiveIntegerField(default=0, verbose_name='مجموع تخفیف')
    grand_total = models.PositiveIntegerField(default=0, verbose_name='مبلغ نهایی قابل پرداخت')

    admin_note = models.TextField(blank=True, verbose_name='یادداشت داخلی ادمین')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    shipped_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'سفارش'
        verbose_name_plural = 'سفارش‌ها'
        ordering = ['-created_at']
        indexes = [models.Index(fields=['order_number']), models.Index(fields=['status'])]

    def __str__(self):
        return self.order_number

    def recalculate_totals(self):
        self.items_total = sum(item.total_price for item in self.items.all())
        self.grand_total = self.items_total + self.shipping_cost - self.discount_total
        self.save(update_fields=['items_total', 'grand_total'])

    def restore_stock(self):
        """
        موجودی محصولات/گونه‌های این سفارش را برمی‌گرداند — برای زمانی که سفارش لغو می‌شود.
        از products.models import در بالای فایل به‌خاطر جلوگیری از import چرخه‌ای انجام نمی‌شود.
        """
        from products.models import Product, ProductVariant
        for item in self.items.select_related('product', 'variant'):
            if item.variant_id:
                ProductVariant.objects.filter(pk=item.variant_id).update(stock=models.F('stock') + item.quantity)
            if item.product_id:
                Product.objects.filter(pk=item.product_id).update(stock=models.F('stock') + item.quantity)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, related_name='order_items')
    variant = models.ForeignKey(ProductVariant, on_delete=models.SET_NULL, null=True, blank=True)
    product_title = models.CharField(max_length=200, verbose_name='نام محصول (در لحظه خرید)')
    variant_label = models.CharField(max_length=100, blank=True, verbose_name='سایز / رنگ انتخابی',
        help_text='مثلا «سایز M / رنگ بنفش» — در لحظه ثبت سفارش ذخیره می‌شود تا حتی با تغییر بعدی محصول، مشخص بماند مشتری چه سایز/رنگی سفارش داده.')
    unit_price = models.PositiveIntegerField(verbose_name='قیمت واحد (در لحظه خرید)')
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        verbose_name = 'آیتم سفارش'
        verbose_name_plural = 'آیتم‌های سفارش'

    def __str__(self):
        return f'{self.product_title} × {self.quantity}'

    @property
    def total_price(self):
        return self.unit_price * self.quantity


class OrderStatusLog(models.Model):
    """تاریخچه تغییر وضعیت سفارش برای شفافیت و پایش"""
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='status_logs')
    old_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.order.order_number}: {self.old_status} -> {self.new_status}'
