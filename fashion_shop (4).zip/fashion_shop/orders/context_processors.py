from .cart_utils import get_or_create_cart


def cart_summary(request):
    """تعداد اقلام سبد خرید در همه صفحات (برای نمایش در هدر) در دسترس است."""
    try:
        cart = get_or_create_cart(request)
        return {'cart_items_count': cart.total_items}
    except Exception:
        return {'cart_items_count': 0}
