import logging
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import models, transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.forms import AddressForm
from accounts.models import Address
from products.models import Product, ProductVariant
from .cart_utils import get_or_create_cart
from .models import Order, OrderItem, OrderStatusLog

logger = logging.getLogger('orders')


def cart_detail(request):
    cart = get_or_create_cart(request)
    return render(request, 'orders/cart_detail.html', {'cart': cart})


@require_POST
def cart_add(request, product_id):
    cart = get_or_create_cart(request)
    product = get_object_or_404(Product, id=product_id, is_active=True)
    variant_id = request.POST.get('variant_id')
    variant = ProductVariant.objects.filter(id=variant_id, product=product).first() if variant_id else None
    quantity = max(1, int(request.POST.get('quantity', 1)))

    if product.variants.exists() and not variant:
        messages.error(request, 'لطفاً سایز و رنگ محصول را انتخاب کنید.')
        return redirect(request.META.get('HTTP_REFERER') or 'orders:cart_detail')

    if variant and variant.stock <= 0:
        messages.error(request, 'این سایز/رنگ در حال حاضر ناموجود است.')
        return redirect(request.META.get('HTTP_REFERER') or 'orders:cart_detail')

    item, created = cart.items.get_or_create(product=product, variant=variant, defaults={'quantity': quantity})
    if not created:
        item.quantity += quantity
        item.save(update_fields=['quantity'])

    messages.success(request, f'«{product.title}» به سبد خرید اضافه شد.')
    return redirect(request.META.get('HTTP_REFERER') or 'orders:cart_detail')


@require_POST
def cart_update(request, item_id):
    cart = get_or_create_cart(request)
    item = get_object_or_404(cart.items, id=item_id)
    quantity = int(request.POST.get('quantity', 1))
    if quantity <= 0:
        item.delete()
    else:
        item.quantity = quantity
        item.save(update_fields=['quantity'])
    return redirect('orders:cart_detail')


@require_POST
def cart_remove(request, item_id):
    cart = get_or_create_cart(request)
    get_object_or_404(cart.items, id=item_id).delete()
    return redirect('orders:cart_detail')


@login_required
def checkout(request):
    """
    کاربر باید ثبت‌نام/ورود کرده باشد تا به این صفحه برسد (login_required).
    این دقیقا همان جریانی است که خواسته شده: کاربر ابتدا کالا را به سبد اضافه می‌کند،
    و برای نهایی‌کردن سفارش به ثبت‌نام/ورود هدایت می‌شود.
    """
    cart = get_or_create_cart(request)
    if cart.total_items == 0:
        messages.warning(request, 'سبد خرید شما خالی است.')
        return redirect('products:product_list')

    addresses = request.user.addresses.all()

    if request.method == 'POST':
        address_id = request.POST.get('address_id')
        if not address_id:
            messages.error(request, 'لطفاً یک آدرس انتخاب کنید یا آدرس جدید ثبت کنید.')
            return render(request, 'orders/checkout.html', {'cart': cart, 'addresses': addresses})

        address = get_object_or_404(Address, id=address_id, user=request.user)

        for item in cart.items.select_related('product', 'variant'):
            if item.variant and item.variant.stock < item.quantity:
                messages.error(request, f'موجودی «{item.product.title}» ({item.variant}) کافی نیست.')
                return render(request, 'orders/checkout.html', {'cart': cart, 'addresses': addresses})
            elif not item.variant and item.product.stock < item.quantity:
                messages.error(request, f'موجودی «{item.product.title}» کافی نیست.')
                return render(request, 'orders/checkout.html', {'cart': cart, 'addresses': addresses})

        with transaction.atomic():
            order = Order.objects.create(user=request.user, address=address, status='pending_payment')
            for item in cart.items.select_related('product', 'variant'):
                variant_label = f'سایز {item.variant.size} / رنگ {item.variant.color}' if item.variant else ''
                OrderItem.objects.create(
                    order=order, product=item.product, variant=item.variant,
                    product_title=item.product.title, variant_label=variant_label,
                    unit_price=item.unit_price, quantity=item.quantity,
                )
                # کسر موجودی — همان لحظه‌ای که سفارش قطعی ثبت می‌شود
                if item.variant:
                    ProductVariant.objects.filter(pk=item.variant.pk).update(stock=models.F('stock') - item.quantity)
                Product.objects.filter(pk=item.product.pk).update(stock=models.F('stock') - item.quantity)

            order.recalculate_totals()
            OrderStatusLog.objects.create(order=order, old_status='', new_status='pending_payment', changed_by=request.user)

            # سبد پس از ایجاد سفارش خالی می‌شود؛ ادامه به درگاه پرداخت زرین‌پال
            cart.items.all().delete()

        return redirect('payments:start_payment', order_number=order.order_number)

    return render(request, 'orders/checkout.html', {'cart': cart, 'addresses': addresses})


STATUS_STEPS = [
    ('pending_payment', 'در انتظار پرداخت'),
    ('confirming', 'در حال تایید سفارش'),
    ('processing', 'در حال پردازش'),
    ('shipped', 'ارسال شده'),
    ('delivered', 'تحویل داده شده'),
]


def _done_statuses(order):
    keys = [k for k, _ in STATUS_STEPS]
    if order.status not in keys:
        return []
    return keys[:keys.index(order.status) + 1]


def track_order(request):
    """پیگیری سفارش با کد رهگیری/شماره سفارش — بدون نیاز به ورود، ولی بدون افشای اطلاعات دیگران."""
    order = None
    error = None
    if request.method == 'POST':
        order_number = request.POST.get('order_number', '').strip().upper()
        order = Order.objects.filter(order_number=order_number).first()
        if not order:
            error = 'سفارشی با این کد یافت نشد.'
    return render(request, 'orders/track_order.html', {
        'order': order, 'error': error, 'status_steps': STATUS_STEPS,
        'done_statuses': _done_statuses(order) if order else [],
    })


@login_required
def order_detail(request, order_number):
    order = get_object_or_404(Order, order_number=order_number, user=request.user)
    return render(request, 'orders/order_detail.html', {
        'order': order, 'status_steps': STATUS_STEPS, 'done_statuses': _done_statuses(order),
    })


@login_required
def order_list(request):
    orders = request.user.orders.all()
    return render(request, 'orders/order_list.html', {'orders': orders})
