"""توابع کمکی برای مدیریت سبد خرید کاربر مهمان/واردشده"""
from .models import Cart


def get_or_create_cart(request):
    if request.user.is_authenticated:
        cart, _ = Cart.objects.get_or_create(user=request.user)
        return cart
    if not request.session.session_key:
        request.session.create()
    cart, _ = Cart.objects.get_or_create(session_key=request.session.session_key, user=None)
    return cart


def merge_guest_cart_into_user(request, user):
    """هنگام ورود کاربر، سبد مهمان با سبد کاربر ادغام می‌شود."""
    if not request.session.session_key:
        return
    try:
        guest_cart = Cart.objects.get(session_key=request.session.session_key, user=None)
    except Cart.DoesNotExist:
        return
    user_cart, _ = Cart.objects.get_or_create(user=user)
    for item in guest_cart.items.all():
        existing = user_cart.items.filter(product=item.product, variant=item.variant).first()
        if existing:
            existing.quantity += item.quantity
            existing.save(update_fields=['quantity'])
        else:
            item.cart = user_cart
            item.save(update_fields=['cart'])
    guest_cart.delete()
