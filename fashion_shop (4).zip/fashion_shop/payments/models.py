from django.db import models
from orders.models import Order


class Payment(models.Model):
    STATUS_CHOICES = (
        ('pending', 'در انتظار پرداخت'),
        ('success', 'موفق'),
        ('failed', 'ناموفق'),
    )
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='payments')
    amount = models.PositiveIntegerField(verbose_name='مبلغ (تومان)')
    authority = models.CharField(max_length=100, blank=True, verbose_name='کد Authority زرین‌پال')
    ref_id = models.CharField(max_length=100, blank=True, verbose_name='کد پیگیری تراکنش (RefID)')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    gateway = models.CharField(max_length=30, default='zarinpal')
    created_at = models.DateTimeField(auto_now_add=True)
    verified_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'تراکنش پرداخت'
        verbose_name_plural = 'تراکنش‌های پرداخت'
        ordering = ['-created_at']

    def __str__(self):
        return f'پرداخت {self.order.order_number} - {self.get_status_display()}'
