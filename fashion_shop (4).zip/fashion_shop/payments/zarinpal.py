"""
اتصال به درگاه پرداخت زرین‌پال (REST API نسخه ۴)
مستندات رسمی: https://docs.zarinpal.com/paymentGateway/

فقط کافیست ZARINPAL_MERCHANT_ID واقعی را در متغیر محیطی قرار دهید
و ZARINPAL_SANDBOX=False کنید تا روی حالت واقعی کار کند.
"""
import logging
import requests
from django.conf import settings
from django.urls import reverse

logger = logging.getLogger('payments')

SANDBOX_BASE = 'https://sandbox.zarinpal.com/pg/v4/payment/'
PRODUCTION_BASE = 'https://payment.zarinpal.com/pg/v4/payment/'
SANDBOX_STARTPAY = 'https://sandbox.zarinpal.com/pg/StartPay/'
PRODUCTION_STARTPAY = 'https://payment.zarinpal.com/pg/StartPay/'


class ZarinpalError(Exception):
    pass


def _base_url():
    return SANDBOX_BASE if settings.ZARINPAL_SANDBOX else PRODUCTION_BASE


def _startpay_url():
    return SANDBOX_STARTPAY if settings.ZARINPAL_SANDBOX else PRODUCTION_STARTPAY


def request_payment(request, amount_toman: int, description: str, mobile: str = '') -> str:
    """درخواست ایجاد تراکنش؛ در صورت موفقیت لینک انتقال به درگاه را برمی‌گرداند."""
    callback_url = request.build_absolute_uri(reverse('payments:verify_payment'))
    payload = {
        'merchant_id': settings.ZARINPAL_MERCHANT_ID,
        'amount': amount_toman * 10,  # زرین‌پال مبلغ را به ریال می‌خواهد
        'description': description,
        'callback_url': callback_url,
        'metadata': {'mobile': mobile} if mobile else {},
    }
    try:
        resp = requests.post(_base_url() + 'request.json', json=payload, timeout=10)
        data = resp.json()
    except requests.RequestException as e:
        logger.error('Zarinpal request error: %s', e)
        raise ZarinpalError('ارتباط با درگاه پرداخت برقرار نشد.')

    if data.get('data', {}).get('code') == 100:
        authority = data['data']['authority']
        return authority, _startpay_url() + authority

    errors = data.get('errors', {})
    logger.error('Zarinpal request failed: %s', errors)
    raise ZarinpalError(f'خطا در ایجاد تراکنش: {errors}')


def verify_payment(amount_toman: int, authority: str):
    """تایید تراکنش پس از بازگشت از درگاه. خروجی: (is_success, ref_id)"""
    payload = {
        'merchant_id': settings.ZARINPAL_MERCHANT_ID,
        'amount': amount_toman * 10,
        'authority': authority,
    }
    try:
        resp = requests.post(_base_url() + 'verify.json', json=payload, timeout=10)
        data = resp.json()
    except requests.RequestException as e:
        logger.error('Zarinpal verify error: %s', e)
        return False, None

    result = data.get('data', {})
    if result.get('code') in (100, 101):
        return True, result.get('ref_id')
    return False, None
