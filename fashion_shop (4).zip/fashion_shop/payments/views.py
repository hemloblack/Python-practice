import logging
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from orders.models import Order, OrderStatusLog
from .models import Payment
from .zarinpal import ZarinpalError, request_payment, verify_payment

logger = logging.getLogger('payments')


@login_required
def start_payment(request, order_number):
    order = get_object_or_404(Order, order_number=order_number, user=request.user)
    if order.status != 'pending_payment':
        messages.info(request, 'این سفارش قبلاً پرداخت شده است.')
        return redirect('orders:order_detail', order_number=order.order_number)

    try:
        authority, pay_url = request_payment(
            request, order.grand_total,
            description=f'پرداخت سفارش {order.order_number}',
            mobile=order.user.phone_number,
        )
    except ZarinpalError as e:
        messages.error(request, str(e))
        return redirect('orders:order_detail', order_number=order.order_number)

    Payment.objects.create(order=order, amount=order.grand_total, authority=authority, status='pending')
    return redirect(pay_url)


def verify_payment_view(request):
    authority = request.GET.get('Authority')
    status_param = request.GET.get('Status')
    payment = Payment.objects.filter(authority=authority).order_by('-created_at').first()

    if not payment:
        messages.error(request, 'تراکنش یافت نشد.')
        return redirect('core:home')

    order = payment.order

    if status_param != 'OK':
        payment.status = 'failed'
        payment.save(update_fields=['status'])
        messages.error(request, 'پرداخت لغو شد یا ناموفق بود.')
        return redirect('orders:order_detail', order_number=order.order_number)

    success, ref_id = verify_payment(payment.amount, authority)
    if success:
        payment.status = 'success'
        payment.ref_id = ref_id or ''
        payment.verified_at = timezone.now()
        payment.save(update_fields=['status', 'ref_id', 'verified_at'])

        old_status = order.status
        order.status = 'confirming'
        order.confirmed_at = timezone.now()
        order.save(update_fields=['status', 'confirmed_at'])
        OrderStatusLog.objects.create(order=order, old_status=old_status, new_status='confirming', changed_by=None)

        messages.success(request, f'پرداخت با موفقیت انجام شد. کد پیگیری: {ref_id}')
    else:
        payment.status = 'failed'
        payment.save(update_fields=['status'])
        messages.error(request, 'تایید پرداخت ناموفق بود.')

    return redirect('orders:order_detail', order_number=order.order_number)
