from django.contrib import admin
from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('order', 'amount', 'status', 'ref_id', 'created_at', 'verified_at')
    list_filter = ('status', 'gateway')
    search_fields = ('order__order_number', 'ref_id', 'authority')
    readonly_fields = [f.name for f in Payment._meta.fields]

    def has_add_permission(self, request):
        return False
