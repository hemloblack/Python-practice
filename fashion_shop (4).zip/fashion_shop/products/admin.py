from django.contrib import admin
from .models import Category, Product, ProductImage, ProductVariant, ProductReview


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


class ProductVariantInline(admin.TabularInline):
    model = ProductVariant
    extra = 1


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent', 'is_active', 'order')
    list_filter = ('is_active', 'parent')
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'price', 'discount_percent', 'final_price_display', 'stock', 'is_active', 'is_featured')
    list_filter = ('category', 'gender', 'is_active', 'is_featured')
    search_fields = ('title', 'sku', 'brand')
    prepopulated_fields = {'slug': ('title',)}
    inlines = [ProductImageInline, ProductVariantInline]
    list_editable = ('price', 'discount_percent', 'stock', 'is_active', 'is_featured')

    def final_price_display(self, obj):
        return f'{obj.final_price:,} تومان'
    final_price_display.short_description = 'قیمت نهایی'


@admin.register(ProductReview)
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ('product', 'user', 'rating', 'is_approved', 'created_at')
    list_filter = ('is_approved', 'rating')
    actions = ['approve_reviews']

    def approve_reviews(self, request, queryset):
        queryset.update(is_approved=True)
    approve_reviews.short_description = 'تایید نظرات انتخاب‌شده'
