from django import forms
from django.forms import inlineformset_factory
from .models import Category, MAX_IMAGE_SIZE_MB, Product, ProductImage, ProductVariant, validate_image_size


class ProductForm(forms.ModelForm):
    """فرم کامل ثبت/ویرایش محصول برای پنل ادمین سایت (غیر از django-admin)"""

    class Meta:
        model = Product
        fields = [
            'title', 'category', 'brand', 'gender', 'short_description', 'description',
            'material', 'care_instructions', 'price', 'discount_percent', 'stock',
            'is_active', 'is_featured',
        ]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-input'}),
            'category': forms.Select(attrs={'class': 'form-input'}),
            'brand': forms.TextInput(attrs={'class': 'form-input'}),
            'gender': forms.Select(attrs={'class': 'form-input'}),
            'short_description': forms.TextInput(attrs={'class': 'form-input'}),
            'description': forms.Textarea(attrs={'class': 'form-input', 'rows': 6}),
            'material': forms.TextInput(attrs={'class': 'form-input'}),
            'care_instructions': forms.Textarea(attrs={'class': 'form-input', 'rows': 3}),
            'price': forms.NumberInput(attrs={'class': 'form-input'}),
            'discount_percent': forms.NumberInput(attrs={'class': 'form-input', 'min': 0, 'max': 90}),
            'stock': forms.NumberInput(attrs={'class': 'form-input'}),
        }


class ProductImageForm(forms.ModelForm):
    """
    فرم تک‌تکِ تصاویر داخل formset.
    نکته فنی مهم: فیلد 'order' عمداً از فرم حذف شده. چون مقدار پیش‌فرض مدل (order=0)
    باعث می‌شد فرم‌های خالیِ اضافه (extra) به‌غلط «تغییر یافته» تشخیص داده بشن و
    کل formset نامعتبر بشه — یعنی هیچ‌کدوم از عکس‌ها ذخیره نمی‌شدن، حتی وقتی فقط
    یکی از سه فیلد عکس رو پر می‌کردید. ترتیب تصاویر به‌صورت خودکار بر اساس ترتیب فرم تنظیم می‌شود.
    """
    image = forms.ImageField(
        required=False, validators=[validate_image_size],
        widget=forms.ClearableFileInput(attrs={'class': 'form-input', 'accept': 'image/*'}),
        help_text=f'هر فرمت تصویری، حداکثر {MAX_IMAGE_SIZE_MB} مگابایت.',
    )

    class Meta:
        model = ProductImage
        fields = ['image', 'alt_text', 'is_main']
        widgets = {
            'alt_text': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'توضیح تصویر (اختیاری)'}),
        }


ProductImageFormSet = inlineformset_factory(
    Product, ProductImage,
    form=ProductImageForm,
    extra=3, can_delete=True,
)


class ProductVariantForm(forms.ModelForm):
    """
    فیلدهای stock و extra_price عمداً به‌صورت صریح با required=False بازتعریف شده‌اند
    تا همان باگ فرم تصاویر (مقدار پیش‌فرض مدل باعث نامعتبر شدن فرم‌های خالی می‌شد) رخ ندهد.
    """
    stock = forms.IntegerField(required=False, min_value=0, widget=forms.NumberInput(attrs={'class': 'form-input'}))
    extra_price = forms.IntegerField(required=False, widget=forms.NumberInput(attrs={'class': 'form-input'}))

    class Meta:
        model = ProductVariant
        fields = ['size', 'color', 'color_hex', 'stock', 'extra_price']
        widgets = {
            'size': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'مثلا M / L / 42'}),
            'color': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'مثلا بنفش'}),
            'color_hex': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '#8B5CF6'}),
        }

    def clean_stock(self):
        return self.cleaned_data.get('stock') or 0

    def clean_extra_price(self):
        return self.cleaned_data.get('extra_price') or 0


ProductVariantFormSet = inlineformset_factory(
    Product, ProductVariant,
    form=ProductVariantForm,
    extra=3, can_delete=True,
)


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'parent', 'icon', 'is_active', 'order']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-input'}),
            'parent': forms.Select(attrs={'class': 'form-input'}),
            'order': forms.NumberInput(attrs={'class': 'form-input'}),
        }
