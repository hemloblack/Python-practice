from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, render

from .models import Category, Product


def product_list(request, slug=None):
    products = Product.objects.filter(is_active=True).prefetch_related('images')
    category = None
    if slug:
        category = get_object_or_404(Category, slug=slug, is_active=True)
        products = products.filter(category=category)

    gender = request.GET.get('gender')
    if gender:
        products = products.filter(gender=gender)

    sort = request.GET.get('sort')
    if sort == 'cheap':
        products = products.order_by('price')
    elif sort == 'expensive':
        products = products.order_by('-price')
    elif sort == 'discount':
        products = products.order_by('-discount_percent')

    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get('page'))

    categories = Category.objects.filter(is_active=True, parent=None)
    return render(request, 'products/product_list.html', {
        'page_obj': page_obj, 'category': category, 'categories': categories,
    })


def product_search(request):
    query = request.GET.get('q', '').strip()
    products = Product.objects.filter(is_active=True)
    if query:
        products = products.filter(
            Q(title__icontains=query) | Q(brand__icontains=query) | Q(short_description__icontains=query)
        )
    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get('page'))
    categories = Category.objects.filter(is_active=True, parent=None)
    return render(request, 'products/product_search.html', {'page_obj': page_obj, 'query': query, 'categories': categories})


def product_detail(request, slug):
    product = get_object_or_404(Product.objects.prefetch_related('images', 'variants', 'reviews'), slug=slug, is_active=True)
    related = Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk)[:4]
    reviews = product.reviews.filter(is_approved=True)
    variants = product.variants.all()
    return render(request, 'products/product_detail.html', {
        'product': product, 'related': related, 'reviews': reviews, 'variants': variants,
    })
