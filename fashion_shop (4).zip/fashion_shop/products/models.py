from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
import uuid


MAX_IMAGE_SIZE_MB = 12


def validate_image_size(value):
    """اجازه هر فرمت و ابعادی از تصویر را می‌دهد؛ فقط حجم فایل را محدود می‌کند."""
    max_bytes = MAX_IMAGE_SIZE_MB * 1024 * 1024
    if value.size > max_bytes:
        raise ValidationError(f'حجم تصویر نباید بیشتر از {MAX_IMAGE_SIZE_MB} مگابایت باشد.')


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='نام دسته‌بندی')
    slug = models.SlugField(max_length=120, unique=True, blank=True, allow_unicode=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children', verbose_name='دسته والد')
    icon = models.ImageField(upload_to='categories/', blank=True, null=True, verbose_name='آیکون')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    order = models.PositiveIntegerField(default=0, verbose_name='ترتیب نمایش')

    class Meta:
        verbose_name = 'دسته‌بندی'
        verbose_name_plural = 'دسته‌بندی‌ها'
        ordering = ['order', 'name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)


class Product(models.Model):
    """محصول اصلی. صفحه نمایش تمام‌صفحه محصول از این مدل ساخته می‌شود."""

    GENDER_CHOICES = (('men', 'مردانه'), ('women', 'زنانه'), ('kids', 'بچگانه'), ('unisex', 'یونیسکس'))

    title = models.CharField(max_length=200, verbose_name='نام محصول')
    slug = models.SlugField(max_length=220, unique=True, blank=True, allow_unicode=True)
    sku = models.CharField('کد محصول (SKU)', max_length=40, unique=True, default=uuid.uuid4, editable=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='products', verbose_name='دسته‌بندی')
    brand = models.CharField(max_length=100, blank=True, verbose_name='برند')
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default='unisex', verbose_name='جنسیت')
    short_description = models.CharField(max_length=300, blank=True, verbose_name='توضیح کوتاه')
    description = models.TextField(verbose_name='توضیحات کامل')
    material = models.CharField(max_length=150, blank=True, verbose_name='جنس پارچه')
    care_instructions = models.TextField(blank=True, verbose_name='راهنمای نگهداری و شستشو')

    price = models.PositiveIntegerField(validators=[MinValueValidator(0)], verbose_name='قیمت (تومان)')
    discount_percent = models.PositiveSmallIntegerField(default=0, verbose_name='درصد تخفیف')

    stock = models.PositiveIntegerField(default=0, verbose_name='موجودی انبار')
    is_active = models.BooleanField(default=True, verbose_name='فعال / قابل نمایش')
    is_featured = models.BooleanField(default=False, verbose_name='ویژه / پیشنهادی')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'محصول'
        verbose_name_plural = 'محصولات'
        ordering = ['-created_at']
        indexes = [models.Index(fields=['slug']), models.Index(fields=['is_active', 'is_featured'])]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title, allow_unicode=True)
            slug = base_slug
            i = 1
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                i += 1
                slug = f'{base_slug}-{i}'
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('products:product_detail', kwargs={'slug': self.slug})

    @property
    def final_price(self):
        if self.discount_percent:
            return int(self.price * (100 - self.discount_percent) / 100)
        return self.price

    @property
    def in_stock(self):
        return self.stock > 0

    @property
    def main_image(self):
        img = self.images.filter(is_main=True).first() or self.images.first()
        return img.image.url if img else None


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='images', verbose_name='محصول')
    image = models.ImageField(upload_to='products/%Y/%m/', validators=[validate_image_size], verbose_name='تصویر')
    alt_text = models.CharField(max_length=150, blank=True, verbose_name='متن جایگزین (SEO)')
    is_main = models.BooleanField(default=False, verbose_name='تصویر اصلی')
    order = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = 'تصویر محصول'
        verbose_name_plural = 'تصاویر محصول'
        ordering = ['order']

    def __str__(self):
        return f'تصویر {self.product.title}'


class ProductVariant(models.Model):
    """سایز/رنگ محصول با موجودی جداگانه (اختیاری ولی رایج برای پوشاک)"""
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='variants', verbose_name='محصول')
    size = models.CharField(max_length=20, verbose_name='سایز')
    color = models.CharField(max_length=50, verbose_name='رنگ')
    color_hex = models.CharField(max_length=7, blank=True, help_text='#RRGGBB', verbose_name='کد رنگ')
    stock = models.PositiveIntegerField(default=0, verbose_name='موجودی این سایز/رنگ')
    extra_price = models.IntegerField(default=0, verbose_name='افزایش/کاهش قیمت نسبت به قیمت پایه')

    class Meta:
        verbose_name = 'گونه محصول (سایز/رنگ)'
        verbose_name_plural = 'گونه‌های محصول'
        unique_together = ('product', 'size', 'color')

    def __str__(self):
        return f'{self.product.title} - {self.size} / {self.color}'


class ProductReview(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='reviews', verbose_name='محصول')
    user = models.ForeignKey('accounts.User', on_delete=models.CASCADE, related_name='reviews', verbose_name='کاربر')
    rating = models.PositiveSmallIntegerField(default=5, verbose_name='امتیاز (۱ تا ۵)')
    comment = models.TextField(blank=True, verbose_name='نظر')
    is_approved = models.BooleanField(default=False, verbose_name='تایید شده توسط ادمین')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'نظر کاربر'
        verbose_name_plural = 'نظرات کاربران'
        ordering = ['-created_at']

    def __str__(self):
        return f'نظر {self.user} روی {self.product}'
