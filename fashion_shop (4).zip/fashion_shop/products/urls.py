from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('category/<uslug:slug>/', views.product_list, name='category_detail'),
    path('search/', views.product_search, name='product_search'),
    path('<uslug:slug>/', views.product_detail, name='product_detail'),
]
